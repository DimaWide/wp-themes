<?php

get_header();
?>

<?php get_template_part('template-parts/sct-1-featured-fields'); ?>

<?php get_template_part('template-parts/sct-6-tables'); ?>

<?php get_template_part('template-parts/sct-3-form'); ?>

<?php get_template_part('template-parts/sct-4-dex-paid'); ?>

<?php get_template_part('template-parts/sct-5-big-buys'); ?>

<?php get_template_part('template-parts/sct-2-we-are'); ?>


<?php
get_footer();
