<?php

/**
 * Template Name: Order Page
 */

 get_header();
 ?>
 
 <?php get_template_part('template-parts/sct-7-promote'); ?>
 
<?php get_template_part('template-parts/sct-8-gooner'); ?>

<?php get_template_part('template-parts/sct-9-we-are'); ?>
 
 <?php
 get_footer();
 