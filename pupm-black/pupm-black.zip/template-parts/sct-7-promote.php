<?php


?>
<!-- sct-7-promote -->
<div class="sct-7-promote">
     <div class="data-container wcl-container">
         <h2 class="data-title">
             PROMOTE YOUR TOKEN
         </h2>
 
         <form class="data-form">
             <div class="data-circles mod-1">
                 <div class="data-circles-item"></div>
                 <div class="data-circles-item"></div>
                 <div class="data-circles-item"></div>
             </div>
 
             <div class="data-form-inner">
                 <input type="text" name="mint" placeholder="Enter Contract Address" required>
                 <input type="submit" value="CHECK">
             </div>
         </form>
     </div>
 </div>
 